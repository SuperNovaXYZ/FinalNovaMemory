/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   memoryTest.h
 * Author: student
 *
 * Created on March 15, 2023, 8:33 PM
 */

#ifndef MEMORYTEST_H
#define MEMORYTEST_H

#ifdef __cplusplus
extern "C" {
#endif


int memoryTestOne();
int memoryTestTwo();
int memoryTestThree();


#ifdef __cplusplus
}
#endif

#endif /* MEMORYTEST_H */

